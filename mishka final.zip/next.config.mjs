export default {
    experimental: { typedRoutes: true },
    reactStrictMode: true,
}